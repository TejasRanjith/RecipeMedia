library my_prj.globals;

bool isLoggedIn = false;