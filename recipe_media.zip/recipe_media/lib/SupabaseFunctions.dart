import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:recipe_media/HomeScreen.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:image/image.dart' as img;

const supabaseUrl = 'https://umncqlsqzzhvwpeuegok.supabase.co';
const supabaseKey =
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVtbmNxbHNxenpodndwZXVlZ29rIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MjEyMzg1MDgsImV4cCI6MjAzNjgxNDUwOH0.htVdbfNfffnHdAnUGMxJDaRfKxR2_AYBlIxfKXqvxSg';

final init = Supabase.initialize(url: supabaseUrl, anonKey: supabaseKey);
final supabase = SupabaseClient(supabaseUrl, supabaseKey);

String getCurrentUserId() {
  final supabase = Supabase.instance.client;
  final user = supabase.auth.currentUser;

  if (user != null) {
    return user.id;
  } else {
    // Handle case where user is not logged in
    return 'empty_bruv';
  }
}

final user = getCurrentUserId();
String imageUrl(String name) {
  try {
    return supabase.storage.from('images').getPublicUrl('$user+$name.png');
  } catch (e) {
    print(e);
    return 'https://via.placeholder.com/150';
  }
}

Card ProfileCard(Map<String, dynamic> note) {
  // Map<String, dynamic> note = {
  //   'title': 'title',
  //   'description': 'description',
  //   'kcal': 'kcal',
  //   'prepTime': 'prepTime',
  //   'imageName': 'imageName',
  // };
  return Card(
    elevation: 4,
    child: Row(
      children: [
        Image.network(
          imageUrl(note['imageName']), // replace with your image asset
          height: 100,
          width: 200,
          fit: BoxFit.cover,
        ),
        Column(
          children: [
            Text(
              note['title'],
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Column(
              children: [
                Text(
                  note['description'],
                  style: const TextStyle(fontSize: 14, color: Colors.grey),
                ),
                Text(
                  "${note['kcal']} kcal",
                  style: const TextStyle(fontSize: 14, color: Colors.grey),
                ),
                Text(
                  note['prepTime'],
                  style: const TextStyle(fontSize: 14, color: Colors.orange),
                ),
              ],
            ),
          ],
        ),
      ],
    ),
  );
}

void addDataDB(
  List<TextEditingController> ingredientControllers,
  List<TextEditingController> stepControllers,
  TextEditingController titleController,
  TextEditingController descriptionController,
  TextEditingController kcalController,
  TextEditingController prepTimeController,
  TextEditingController imageUrlController,
  String tableName,
) async {
  List<String> ingredients =
      ingredientControllers.map((controller) => controller.text).toList();
  List<String> steps =
      stepControllers.map((controller) => controller.text).toList();
  String ingredientsJsonArray =
      '[${ingredients.map((text) => '"$text"').join(', ')}]';
  String stepsJsonArray = '[${steps.map((text) => '"$text"').join(', ')}]';
  try {
    final response = await supabase.from('$tableName').insert({
      'title': titleController.text,
      'description': descriptionController.text,
      'kcal': int.parse(kcalController.text),
      'prepTime': prepTimeController.text,
      'imageName': imageUrlController.text,
      'ingredients': ingredientsJsonArray,
      'steps': stepsJsonArray,
    });
  } catch (e) {
    print(e);
  }
}

Future<void> pickImage(String name) async {
  final imagePicker = ImagePicker();
  final XFile? image = await imagePicker.pickImage(source: ImageSource.gallery);
  final Uint8List bytes = await image!.readAsBytes();
  final user = await getCurrentUserId();
  try {
    var response = await supabase.storage
        .from('images')
        .uploadBinary('$user+$name.png', bytes);
  } catch (e) {
    print(e);
  }
}

Future<void> authentication(
    BuildContext context, String pass, String email) async {
  final sm = ScaffoldMessenger.of(context);
  try {
    final authResponse = await supabase.auth.signInWithPassword(
      password: pass,
      email: email,
    );

    final authSubscription = supabase.auth.onAuthStateChange.listen((data) {
      final AuthChangeEvent event = data.event;
      final Session? session = data.session;

      if (event == AuthChangeEvent.signedIn) {
        sm.showSnackBar(
          SnackBar(
            content: Text('Logged in as ${authResponse.user!.email}'),
          ),
        );
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const HomeScreen()),
        );
      }
    });
  } catch (error) {
    sm.showSnackBar(
      SnackBar(
        content: Text('Error logging in: $error'),
      ),
    );
  }
}
