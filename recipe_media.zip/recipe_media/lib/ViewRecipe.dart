import 'package:flutter/material.dart';
import 'package:recipe_media/CreateNewReceipe.dart';
import 'package:recipe_media/supabaseFunctions.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

Future<void> main() async {
  runApp(const MyApp());
}

final supabase = Supabase.instance.client;

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: ViewRecipe(),
    );
  }
}

class ViewRecipe extends StatefulWidget {
  const ViewRecipe({super.key});

  @override
  State<ViewRecipe> createState() => _ViewRecipeState();
}

class _ViewRecipeState extends State<ViewRecipe> {
  late Stream<List<Map<String, dynamic>>> _data;
  @override
  void initState() {
    super.initState();
    _data = supabase.from(tableName).stream(primaryKey: ["id"]);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('View Recipe'),
      ),
      body: Container(
        width: 700,
        height: 300,
        child: ProfileCard()),
      
      //Container(
      //   decoration: BoxDecoration(
      //     border: Border.all(color: Colors.black, width: 20),
      //   ),
      //   child: StreamBuilder<List<Map<String, dynamic>>>(
      //     stream: _data,
      //     builder: (context, snapshot) {
      //       if (!snapshot.hasData) {
      //         return const Center(child: CircularProgressIndicator());
      //       }
            
      //       final notes = snapshot.data!;
      //       return ListView.builder(
      //         itemCount: notes.length,
      //         itemBuilder: (context, index) {
      //           final note = notes[index];
      //           return ListTile(
      //             title: Text(note['title']),
      //             subtitle: Text(note['description']),
      //           );
      //         },
      //       );
      //     },
      //   ),
      // ),
    );
  }
}

Card ProfileCard() {
  Map<String, dynamic> note = {
    'title': 'title',
    'description': 'description',
    'kcal': 'kcal',
    'prepTime': 'prepTime',
    'imageName': 'imageName',
  };
  return Card(
    elevation: 4,
    child: Row(
      children: [
        Image.asset(
          'assets/images/burger.png', // replace with your image asset
          height: 100,
          width: 200,
          fit: BoxFit.contain,
        ),
        Column(
          children: [
            Text(
              note['title'],
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Column(
              children: [
                Text(
                  note['description'],
                  style: const TextStyle(fontSize: 14, color: Colors.grey),
                ),
                Text(
                  "${note['kcal']} kcal",
                  style: const TextStyle(fontSize: 14, color: Colors.grey),
                ),
                Text(
                  note['prepTime'],
                  style: const TextStyle(fontSize: 14, color: Colors.orange),
                ),
              ],
            ),
          ],
        ),
      ],
    ),
  );
}